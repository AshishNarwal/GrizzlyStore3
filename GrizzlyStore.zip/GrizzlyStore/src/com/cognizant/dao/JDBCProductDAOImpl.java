package com.cognizant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.entity.Product;
import com.cognizant.helper.ConnectionManager;

public class JDBCProductDAOImpl implements ProductDAO{
	
	private ConnectionManager manager=new ConnectionManager();

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		boolean result=false;
		Connection connection=manager.openConnection();
		try {
			PreparedStatement statement=connection.prepareStatement("insert into PRODUCTDATA values(?,?,?,?)");
			statement.setInt(1,product.getProductID());
			statement.setString(2,product.getProductName());
			statement.setString(3,product.getProductCategory());
			statement.setInt(4,product.getProductPrice());
			int rows=statement.executeUpdate();
			if(rows>0)
				result=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(result==true)
			return true;
		else
			return false;
		
	}

	@Override
	public boolean checkProduct(int productId) {
		// TODO Auto-generated method stub
		boolean result=false;
		Connection connection=manager.openConnection();
		try{
			PreparedStatement statement=connection.prepareStatement("Select * from PRODUCTDATA where PRODUCT_ID=?");
			statement.setInt(1,productId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				result=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		manager.closeConnection();
		return result;
		
	}

	@Override
	public List<Product> viewProduct() {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		List<Product> result=new ArrayList<>();
		
		return null;
	}
	   
	




}
