package com.cognizant.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.AdminDAO;
import com.cognizant.helper.FactoryAdminDAO;


/**
 * Servlet implementation class AmindLoginCookieClass
 */
@WebServlet(name = "AmindLoginCookie", urlPatterns = { "/adminlogin" })
public class AdminLoginClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       static int count=0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub
		//super.doGet(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		System.out.println("********************************");
		AdminDAO adminDAO=FactoryAdminDAO.createAdminDAO();
		boolean result=adminDAO.authAdmin(username, password);
		
		if(result)
		{
			Cookie cookie=new Cookie("AdminLoginCookie",String.valueOf(username));
			cookie.setMaxAge(1*24*60*60);
			response.addCookie(cookie);
			response.sendRedirect("http://localhost:8082/GrizzlyStore/welcomecookie");
			
		}
		else
		{   
			if(count==3)
			{
				response.getWriter().println("Login Failed as the number of attempt exceeded !!!!!");
				count=0;
				                    
			}
			else
			{
				count++;
				response.sendRedirect("http://localhost:8082/GrizzlyStore/AdminLogin.html");
				 
			}
				
		}
		
			

	}



}